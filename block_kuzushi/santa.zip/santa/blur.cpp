#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <functional>
#include <vector>
#include <thread>
using namespace std;

vector<float> buffer;
struct Job : thread {
	mutex mtx;
	condition_variable cv;
	bool running = true;
	function<void()> task;
	Job() {
		swap(thread([this] {
			run();
		}));
	}
	~Job() {
		running = false;
		cv.notify_all();
		join();
	}
	void setTask(function<void()> t) {
		lock_guard<mutex> lock(mtx);
		task = move(t);
		cv.notify_all();
	}
	void run() {
		while(running) {
			function<void()> fetch;
			{
				unique_lock<mutex> lock(mtx);
				cv.wait(lock, [&]{ return !running || task; });
				if(!running) break;
				fetch = move(task);
			}
			fetch();
		}
	}
};
//vector<Job> threads(thread::hardware_concurrency());
vector<Job> threads(1);
mutex mtx;
condition_variable cv;

extern "C" __declspec(dllexport) void __cdecl Exec(unsigned int p[], int w, int h, int cx, int cy, int cw, int ch, float kernel[], int len) {
	if(buffer.size() < w * h) {
		buffer.resize(w * h);
	}
	const auto d = buffer.data();
	const int t = w * h;
	const auto division = threads.size();
	atomic_int complete = division;
	// �������u���[
	for(auto i = division;i--;) {
		threads[i].setTask([&, i] {
			int y = cy + ch * i / division;
			int yend = cy + ch * (i + 1) / division;
			for(;y < yend;y++) {
				for(int x = cx;x < cx + cw;x++) {
					const int i = x + y * w;
					float a = 0.f;
					for(int j = max(1 - len, cx - x), end = min(len - 1, cx + cw - x);j < end;j++) {
						a += (p[i + j] >> 24) * kernel[abs(j)];
					}
					d[y + x * h] = a;
				}
			}
			if(--complete == 0) {
				cv.notify_all();
			}
		});
	}
	{
		unique_lock<mutex> lock(mtx);
		cv.wait(lock, [&]{ return complete == 0; });
	}
	complete = division;
	// �c�����u���[
	for(auto i = division;i--;) {
		threads[i].setTask([&, i] {
			int x = cx + cw * i / division;
			int xend = cx + cw * (i + 1) / division;
			for(;x < xend;x++) {
				for(int y = cy;y < cy + ch;y++) {
					const int i = y + x * h;
					float a = 0.f;
					for(int j = max(1 - len, cy - y), end = min(len - 1, cy + ch - y);j < end;j++) {
						a += d[i + j] * kernel[abs(j)];
					}
					p[x + y * w] = static_cast<int>(a) << 24;
				}
			}
			if(--complete == 0) {
				cv.notify_all();
			}
		});
	}
	{
		unique_lock<mutex> lock(mtx);
		cv.wait(lock, [&]{ return complete == 0; });
	}
}
